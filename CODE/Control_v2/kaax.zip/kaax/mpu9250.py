"""
mpu9250.py — minimal driver for the MPU-9250 9-axis IMU.

The MPU-9250 is two chips on one board:
  - MPU-6500 (3-axis accel + 3-axis gyro) at I²C address 0x68
  - AK8963   (3-axis magnetometer)        at I²C address 0x0C, accessed
             through the MPU-6500's auxiliary I²C pass-through.

This driver:
  - Wakes the MPU-6500 from sleep
  - Enables the magnetometer pass-through so the AK8963 is visible on the
    main I²C bus
  - Reads accel + gyro + mag in calibrated units (m/s², rad/s, µT)
  - Computes roll, pitch, yaw via complementary filter (gyro + accel + mag)
  - Returns everything as a single dict ready to be serialised to JSON

It needs only the `smbus2` package (or the older `smbus` works as a fallback).
"""
import math
import time

# ── I²C addresses ────────────────────────────────────────────────────────────
MPU_ADDR   = 0x68      # accel + gyro
MAG_ADDR   = 0x0C      # AK8963 magnetometer

# ── MPU-6500 registers ───────────────────────────────────────────────────────
PWR_MGMT_1     = 0x6B
INT_PIN_CFG    = 0x37
ACCEL_XOUT_H   = 0x3B
TEMP_OUT_H     = 0x41
GYRO_XOUT_H    = 0x43
GYRO_CONFIG    = 0x1B
ACCEL_CONFIG   = 0x1C
SMPLRT_DIV     = 0x19
CONFIG         = 0x1A

# ── AK8963 registers ─────────────────────────────────────────────────────────
AK_WHO_AM_I    = 0x00
AK_CNTL1       = 0x0A
AK_HXL         = 0x03
AK_ST2         = 0x09

# ── Scale factors (datasheet) ────────────────────────────────────────────────
ACCEL_SCALE  = 16384.0          # ±2 g  → LSB / g
GYRO_SCALE   = 131.0            # ±250°/s → LSB / (°/s)
MAG_SCALE    = 0.15             # µT / LSB at 16-bit, 4912 µT range
GRAVITY      = 9.80665          # m/s²


class MPU9250:
    """Simple synchronous driver. Construct once, call .read() on a poll loop."""

    def __init__(self, bus=1):
        # Lazy-import so the rest of the server doesn't crash if smbus2 is
        # missing (e.g. dev laptop without I²C).
        try:
            from smbus2 import SMBus
        except ImportError:
            try:
                from smbus import SMBus  # fallback
            except ImportError as e:
                raise RuntimeError("smbus2 (or smbus) is required") from e
        self._bus = SMBus(bus)
        self._init_mpu()
        self._init_mag()
        # Complementary filter state
        self._roll  = 0.0
        self._pitch = 0.0
        self._yaw   = 0.0
        self._last_t = time.time()

    # ── Setup ────────────────────────────────────────────────────────────────
    def _init_mpu(self):
        # 1. Wake from sleep (clear sleep bit), use best clock source.
        self._bus.write_byte_data(MPU_ADDR, PWR_MGMT_1, 0x01)
        time.sleep(0.05)
        # 2. Set sample rate to 200 Hz (1 kHz / (1+4))
        self._bus.write_byte_data(MPU_ADDR, SMPLRT_DIV, 4)
        # 3. DLPF 41 Hz to filter motor vibration
        self._bus.write_byte_data(MPU_ADDR, CONFIG, 0x03)
        # 4. Gyro range ±250 °/s
        self._bus.write_byte_data(MPU_ADDR, GYRO_CONFIG, 0x00)
        # 5. Accel range ±2 g
        self._bus.write_byte_data(MPU_ADDR, ACCEL_CONFIG, 0x00)
        # 6. Enable I²C pass-through so the AK8963 appears on the main bus
        self._bus.write_byte_data(MPU_ADDR, INT_PIN_CFG, 0x02)
        time.sleep(0.05)

    def _init_mag(self):
        try:
            who = self._bus.read_byte_data(MAG_ADDR, AK_WHO_AM_I)
            if who != 0x48:
                print(f"[IMU] AK8963 WHO_AM_I = 0x{who:02X}, expected 0x48")
            # Continuous measurement mode 2 (100 Hz), 16-bit output
            self._bus.write_byte_data(MAG_ADDR, AK_CNTL1, 0x16)
            time.sleep(0.05)
            self._mag_ok = True
        except Exception as e:
            print(f"[IMU] Magnetometer init failed: {e}")
            self._mag_ok = False

    # ── Raw reads ────────────────────────────────────────────────────────────
    @staticmethod
    def _to_int16(hi, lo):
        v = (hi << 8) | lo
        return v - 0x10000 if v & 0x8000 else v

    def _read_accel_gyro(self):
        """Read 14 bytes starting at ACCEL_XOUT_H — accel + temp + gyro."""
        d = self._bus.read_i2c_block_data(MPU_ADDR, ACCEL_XOUT_H, 14)
        ax = self._to_int16(d[0],  d[1])  / ACCEL_SCALE * GRAVITY
        ay = self._to_int16(d[2],  d[3])  / ACCEL_SCALE * GRAVITY
        az = self._to_int16(d[4],  d[5])  / ACCEL_SCALE * GRAVITY
        # d[6]+d[7] = temperature
        gx = self._to_int16(d[8],  d[9])  / GYRO_SCALE
        gy = self._to_int16(d[10], d[11]) / GYRO_SCALE
        gz = self._to_int16(d[12], d[13]) / GYRO_SCALE
        return ax, ay, az, gx, gy, gz

    def _read_mag(self):
        """Read 6 bytes from the magnetometer (LE byte order, unlike accel)."""
        if not self._mag_ok:
            return 0.0, 0.0, 0.0
        try:
            d = self._bus.read_i2c_block_data(MAG_ADDR, AK_HXL, 7)
            # ST2 (last byte) must be read to release the data registers
            mx = self._to_int16(d[1], d[0]) * MAG_SCALE
            my = self._to_int16(d[3], d[2]) * MAG_SCALE
            mz = self._to_int16(d[5], d[4]) * MAG_SCALE
            return mx, my, mz
        except Exception:
            return 0.0, 0.0, 0.0

    # ── Public ───────────────────────────────────────────────────────────────
    def read(self) -> dict:
        """Return a dict with raw 9-axis values and computed roll/pitch/yaw.

        Units:
          ax, ay, az : m/s²
          gx, gy, gz : °/s
          mx, my, mz : µT
          roll, pitch, yaw : degrees
        """
        ax, ay, az, gx, gy, gz = self._read_accel_gyro()
        mx, my, mz             = self._read_mag()

        now = time.time()
        dt  = max(1e-3, now - self._last_t)
        self._last_t = now

        # Roll / pitch from accelerometer (gravity vector)
        roll_acc  = math.degrees(math.atan2(ay, az))
        pitch_acc = math.degrees(math.atan2(-ax, math.hypot(ay, az)))

        # Complementary filter: gyro integrates fast, accel keeps it honest.
        ALPHA = 0.96
        self._roll  = ALPHA * (self._roll  + gx * dt) + (1 - ALPHA) * roll_acc
        self._pitch = ALPHA * (self._pitch + gy * dt) + (1 - ALPHA) * pitch_acc
        # Yaw: integrate gyro Z, fall back to compass heading if mag is OK.
        if self._mag_ok and (mx or my):
            heading = math.degrees(math.atan2(my, mx))
            if heading < 0:
                heading += 360
            self._yaw = 0.95 * (self._yaw + gz * dt) + 0.05 * heading
        else:
            self._yaw += gz * dt
        # Wrap yaw to 0..360
        self._yaw = self._yaw % 360

        return {
            "ax": ax, "ay": ay, "az": az,
            "gx": gx, "gy": gy, "gz": gz,
            "mx": mx, "my": my, "mz": mz,
            "roll":  self._roll,
            "pitch": self._pitch,
            "yaw":   self._yaw,
            "mag_ok": self._mag_ok,
        }

    def close(self):
        try: self._bus.close()
        except Exception: pass
