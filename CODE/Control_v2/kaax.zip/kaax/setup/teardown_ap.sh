#!/bin/bash
set -e
if [ "$EUID" -ne 0 ]; then echo "Run with sudo."; exit 1; fi
nmcli connection down kaax-ap 2>/dev/null || true
nmcli connection delete kaax-ap 2>/dev/null || true
echo "AP removed.  To reconnect to a normal Wi-Fi:"
echo "    sudo nmcli device wifi connect <SSID> password <PASS>"
