#!/bin/bash
# Disable Kaax auto-start on boot.  Does NOT remove the project files.
set -e
if [ "$EUID" -ne 0 ]; then echo "Run with sudo."; exit 1; fi

systemctl stop kaax.service 2>/dev/null || true
systemctl disable kaax.service 2>/dev/null || true
rm -f /etc/systemd/system/kaax.service
systemctl daemon-reload

echo "Auto-start disabled. You can still run the server manually with:"
echo "    sudo ./run.sh"
