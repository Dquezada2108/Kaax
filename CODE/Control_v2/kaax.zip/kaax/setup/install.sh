#!/bin/bash
# ============================================================================
# Kaax · one-shot install for Raspberry Pi 5
# ============================================================================
# Run ONCE after unzipping kaax on a fresh Pi:
#     bash setup/install.sh
#
# What it does:
#   1. Installs apt deps  (python3-venv, network-manager, v4l-utils, lgpio...)
#   2. Creates a venv in ./venv
#   3. Installs Flask + OpenCV + numpy + reportlab into that venv
#   4. Writes run.sh (the daily-use launcher)
#
# After this runs, daily use is just:
#     sudo ./run.sh
# ============================================================================
set -e

KAAX_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$KAAX_DIR"
echo ">>> Project dir: $KAAX_DIR"

if [ "$EUID" -eq 0 ]; then
  echo "Run this script WITHOUT sudo. It will call sudo itself when needed."
  exit 1
fi

echo ""
echo "[1/4] Installing system packages..."
sudo apt update
sudo apt install -y \
    python3-venv python3-pip python3-lgpio \
    network-manager v4l-utils i2c-tools \
    libjpeg-dev libopenblas0

# Enable the I²C bus (needed for the MPU-9250 IMU)
if [ -f /boot/firmware/config.txt ]; then
  CFG=/boot/firmware/config.txt
elif [ -f /boot/config.txt ]; then
  CFG=/boot/config.txt
else
  CFG=""
fi
if [ -n "$CFG" ] && ! grep -q "^dtparam=i2c_arm=on" "$CFG"; then
  echo ""
  echo "    Enabling I²C in $CFG (will take effect after next reboot)..."
  echo "dtparam=i2c_arm=on" | sudo tee -a "$CFG" > /dev/null
fi

echo ""
echo "[2/4] Creating Python virtual environment..."
if [ ! -d venv ]; then
  python3 -m venv --system-site-packages venv
  # --system-site-packages lets us use apt's python3-lgpio without pip rebuilds
fi

echo ""
echo "[3/4] Installing Python packages into venv..."
./venv/bin/pip install --upgrade pip
./venv/bin/pip install flask opencv-python-headless numpy reportlab smbus2

echo ""
echo "[4/4] Writing run.sh launcher..."
cat > "$KAAX_DIR/run.sh" <<EOF
#!/bin/bash
# Launch Kaax server.  Must be run with sudo to access GPIO and bind port 80.
cd "$KAAX_DIR"
sudo ./venv/bin/python -u server.py
EOF
chmod +x "$KAAX_DIR/run.sh"

echo ""
echo "============================================================"
echo "  INSTALL COMPLETE"
echo "============================================================"
echo ""
echo "Next steps:"
echo "  1. Turn the Pi into a Wi-Fi hotspot:"
echo "       sudo bash setup/setup_ap.sh"
echo ""
echo "  2. Enable auto-start on boot:"
echo "       sudo bash setup/enable_autostart.sh"
echo ""
echo "  3. From your Mac: join Wi-Fi 'Kaax' (pw: kaax2026)"
echo "                    browse to http://192.168.4.1"
echo "                    log in as admin / kaax2026"
echo ""
