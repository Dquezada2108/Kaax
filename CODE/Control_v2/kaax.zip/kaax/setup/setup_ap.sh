#!/bin/bash
# ============================================================================
# Kaax · turn the Pi into a Wi-Fi access point named "Kaax"
# ============================================================================
# Uses NetworkManager (default on Pi OS Bookworm).
# Your Mac connects directly to this network — no router needed.
#
# Usage:  sudo bash setup/setup_ap.sh
# Revert: sudo bash setup/teardown_ap.sh
# ============================================================================
set -e

SSID="Kaax"
PASS="kaax2026"
IFACE="wlan0"
CONN_NAME="kaax-ap"
IP="192.168.4.1"

if [ "$EUID" -ne 0 ]; then echo "Run with sudo."; exit 1; fi

if ! command -v nmcli >/dev/null; then
  echo "nmcli not found.  On Bullseye or older use hostapd+dnsmasq instead."
  exit 1
fi

echo "[1/3] Removing any previous AP profile..."
nmcli connection delete "$CONN_NAME" 2>/dev/null || true

echo "[2/3] Creating AP profile..."
nmcli connection add type wifi ifname "$IFACE" con-name "$CONN_NAME" \
    autoconnect yes ssid "$SSID"
nmcli connection modify "$CONN_NAME" \
    802-11-wireless.mode ap \
    802-11-wireless.band bg \
    802-11-wireless.channel 6 \
    ipv4.method shared \
    ipv4.addresses "$IP/24" \
    ipv6.method disabled \
    wifi-sec.key-mgmt wpa-psk \
    wifi-sec.psk "$PASS"

echo "[3/3] Bringing up hotspot..."
nmcli connection up "$CONN_NAME"

echo ""
echo "============================================================"
echo "  AP READY"
echo "  SSID:     $SSID"
echo "  Password: $PASS"
echo "  URL:      http://$IP"
echo "============================================================"
