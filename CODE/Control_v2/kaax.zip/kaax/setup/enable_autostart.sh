#!/bin/bash
# ============================================================================
# Kaax · enable auto-start on boot
# ============================================================================
# After running this, the Pi will:
#   1. Boot up
#   2. Bring up the Kaax Wi-Fi hotspot automatically
#   3. Start the Kaax server automatically
#
# You never need to open a terminal to use the ROV again.
#
# Usage:  sudo bash setup/enable_autostart.sh
# Undo:   sudo bash setup/disable_autostart.sh
# ============================================================================
set -e

if [ "$EUID" -ne 0 ]; then echo "Run with sudo."; exit 1; fi

KAAX_DIR="$(cd "$(dirname "$0")/.." && pwd)"
echo ">>> Project dir: $KAAX_DIR"

# 1. Make sure the hotspot profile exists (setup_ap.sh already creates this).
#    NetworkManager will bring it up on boot because autoconnect=yes.
if ! nmcli connection show kaax-ap >/dev/null 2>&1; then
  echo "[1/3] No kaax-ap profile found — creating it..."
  bash "$KAAX_DIR/setup/setup_ap.sh"
else
  echo "[1/3] kaax-ap profile exists — ensuring autoconnect is on..."
  nmcli connection modify kaax-ap connection.autoconnect yes
fi

# 2. Install the systemd service with this project's path baked in.
echo "[2/3] Installing systemd service (kaax.service)..."
SERVICE_PATH=/etc/systemd/system/kaax.service
sed "s|KAAX_DIR|$KAAX_DIR|g" "$KAAX_DIR/setup/kaax.service" > "$SERVICE_PATH"
chmod 644 "$SERVICE_PATH"

# 3. Enable & start it.
echo "[3/3] Enabling auto-start..."
systemctl daemon-reload
systemctl enable kaax.service
systemctl restart kaax.service

sleep 2
echo ""
echo "============================================================"
echo "  AUTO-START ENABLED"
echo "============================================================"
echo ""
echo "Service status:"
systemctl is-active kaax.service && echo "  ✓ kaax.service is RUNNING"
echo ""
echo "You can now power-cycle the Pi and everything comes up on its own."
echo ""
echo "Useful commands:"
echo "  sudo systemctl status kaax         # check if running"
echo "  sudo systemctl restart kaax        # restart after code changes"
echo "  sudo systemctl stop kaax           # stop (does NOT disable autostart)"
echo "  sudo journalctl -u kaax -f         # watch live logs"
echo "  sudo bash setup/disable_autostart.sh   # turn autostart off"
echo ""
