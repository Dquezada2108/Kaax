# Kaax — Raspberry Pi 5 Aquatic ROV Control

DAY1 Robotics · Underwater Cleaning System

A self-contained control stack that runs entirely on the Pi. The Pi broadcasts its own Wi-Fi network, your Mac connects directly, no router needed. Everything boots automatically on power-on.

## Features

- **Plain HTTP / Flask** — no WebSockets, no async drivers, no socket.io. Bulletproof.
- **Self-hosted Wi-Fi access point** (`Kaax`, password `kaax2026`)
- **Live MJPEG camera stream** with HSV-based sargassum/vegetation detection
- **Two thrusters** with independent forward/reverse trim sliders (0–100%)
- **Two servos** with degree-based control, ±10° per tap
- **Multi-input** — keyboard, on-screen D-pad, Xbox controller
- **Auto-start on boot** via systemd
- **Login + session logs** — SQLite-backed
- **DAY1 Robotics branding**

## Hardware wiring

| Component         | BCM pin | Physical pin |
|-------------------|---------|--------------|
| ESC Right (U5)    | 18      | 12           |
| ESC Left  (U5)    | 19      | 35           |
| Servo 1           | 12      | 32           |
| Servo 2           | 13      | 33           |
| Common GND        | —       | 6 / 9 / 14 / … |

**All four PWM pins (18, 19, 12, 13) are hardware PWM channels on the Pi 5's RP1 chip.** This is critical: software PWM on arbitrary GPIO pins causes visible servo jitter.

ESCs power from the 14.8 V LiPo, **not** from the Pi.
The Right ESC's 5V BEC powers both servos through a breadboard.
The Left ESC's red wire is **cut and insulated** — never connected.
All grounds (Pi, both ESCs, both servos) tie to a single GND rail.

## Controls

### Mac keyboard
- **↑↓←→** thrusters (binary — held = full signal in that direction)
- **A / D** Servo 1 ±10°
- **W / S** Servo 2 ±10°
- **Space** emergency stop

### Xbox controller (paired via Bluetooth)
- **Left stick** thrusters (binary, any deflection past deadzone = full signal)
- **D-pad ← / →** Servo 1 ±10°
- **D-pad ↑ / ↓** Servo 2 ±10°
- **B button** emergency stop

### On-screen
- D-pad buttons (also work on touch)
- Four trim sliders (R fwd / R rev / L fwd / L rev), each 0–100%
- −10° / +10° buttons next to each servo angle readout
- Big red EMERGENCY STOP button

### PWM ranges
- ESCs: 1100–1900 µs (1500 = neutral)
- Servos: 1000–2000 µs (1500 = 90°)

### Safety
- 1-second motor watchdog (cuts thrusters if no command for 1s)
- Auto-stop when browser tab is hidden
- E-stop resets servos to 90° and thrusters to neutral

## One-time install (fresh Pi OS Bookworm)

Get the code onto the Pi (USB stick, scp, or browser download), then:

```bash
cd ~/kaax
bash setup/install.sh             # 5–10 min — creates venv, installs Flask + OpenCV
sudo bash setup/setup_ap.sh       # turns Pi into Wi-Fi hotspot (Kaax)
sudo bash setup/enable_autostart.sh   # makes the server start on every boot
```

That's it. Reboot once to verify everything comes up automatically:

```bash
sudo reboot
```

After ~60 seconds the `Kaax` Wi-Fi appears. On your Mac, join it (`kaax2026`), go to `http://192.168.4.1`, log in (`admin` / `kaax2026`).

## Daily use

Power the Pi on. Wait. Connect from your Mac. That's the whole workflow.

If you ever need to interact with the Pi:

```bash
# Watch live server logs
sudo journalctl -u kaax -f

# Restart after editing code
sudo systemctl restart kaax

# Stop the service (won't disable autostart)
sudo systemctl stop kaax

# Disable autostart entirely
sudo bash setup/disable_autostart.sh

# Run manually for debugging (without sudo runs on port 8080)
./run.sh                          # or: sudo ./run.sh for port 80 + GPIO
```

## Default users

All have password `kaax2026`:
- `admin`
- `diego`
- `yael`
- `daniel`

To add a user: edit `_hash()` in `server.py` to generate a hash, then insert into `kaax.db`.

## File layout

```
kaax/
├── server.py             # Flask + lgpio + camera thread + HTTP API
├── run.sh                # launcher (created by install.sh)
├── venv/                 # Python virtual env (created by install.sh)
├── kaax.db               # SQLite users + logs (auto-created on first run)
├── README.md
├── templates/            # base, _topbar, login, menu, teleop, logs
├── static/               # style.css, teleop.js, logo.png, logo_sm.png
└── setup/
    ├── install.sh                # one-shot venv + deps install
    ├── setup_ap.sh               # turn Pi into hotspot
    ├── teardown_ap.sh            # revert hotspot to Wi-Fi client
    ├── kaax.service              # systemd unit template
    ├── enable_autostart.sh       # install + enable systemd service
    └── disable_autostart.sh      # stop + remove systemd service
```

## Tuning the sargassum detection

Edit the HSV ranges near the top of the camera section in `server.py`:

```python
SARG_LO, SARG_HI = np.array([8, 80, 60]),  np.array([28, 255, 230])  # orange-brown
VEG_LO,  VEG_HI  = np.array([35, 50, 40]), np.array([85, 255, 230])  # green
```

H is 0–179 in OpenCV. After bringing real beach photos back, run them through a quick `cv2.cvtColor + np.where` script to read the actual HSV values and adjust the bounds.

Then `sudo systemctl restart kaax` and reload Tele-Op on your Mac.

## Troubleshooting

| Symptom | Fix |
|--------|------|
| `lgpio` not installed | `sudo apt install python3-lgpio` |
| Camera says NO SIGNAL | `ls /dev/video*` and `v4l2-ctl --list-devices` |
| Can't reach 192.168.4.1 | `nmcli connection show --active` should list `kaax-ap` |
| Service stuck "activating" | `sudo journalctl -u kaax -n 50 --no-pager` to see the error |
| Mac on Kaax but no GUI | hard reload (`Cmd+Shift+R`); make sure tab is on `http://`, not `https://` |
| Trim sliders feel wrong direction | flip the ESC reverse setting (or swap any two motor wires) |
