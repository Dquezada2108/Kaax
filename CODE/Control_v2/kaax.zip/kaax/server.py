#!/usr/bin/env python3
"""
Kaax · ROV Control Server (v2 — simplified)
===========================================

Plain Flask. No SocketIO, no gevent, no eventlet, no monkey-patching.
Motor + servo commands flow over regular HTTP POSTs at ~15 Hz.
Camera streams as MJPEG. Detection runs in a background thread.

Run:   sudo ./venv/bin/python server.py
Visit: http://192.168.4.1   (when Mac is connected to "Kaax" Wi-Fi)
       http://<pi-lan-ip>:8080 on your home Wi-Fi for dev

Default login: admin / kaax2026
"""
import os
import sys
import time
import sqlite3
import hashlib
import secrets
import threading
from datetime import datetime
from functools import wraps

from flask import (
    Flask, render_template, request, jsonify, session,
    redirect, url_for, Response, send_from_directory
)

# ─────────────────────────────────────────────────────────────────────────────
# GPIO  (lgpio — Pi 5 compatible)
# ─────────────────────────────────────────────────────────────────────────────
GPIO_OK = False
_chip = None
try:
    import lgpio
    for chip_id in (4, 0):            # Pi 5 = 4, Pi 4 = 0
        try:
            _chip = lgpio.gpiochip_open(chip_id)
            GPIO_OK = True
            print(f"[GPIO] Opened gpiochip{chip_id}")
            break
        except Exception:
            continue
    if not GPIO_OK:
        print("[GPIO] Could not open any gpiochip — simulation mode.")
except ImportError:
    print("[GPIO] lgpio not installed — simulation mode.")

# Pin map  (BCM numbering)
ESC_R_PIN  = 18   # Right thruster
ESC_L_PIN  = 19   # Left thruster
SERVO1_PIN = 12   # Servo 1 — hardware PWM (phys pin 32). Left Trigger / A-D keys
SERVO2_PIN = 13   # Servo 2 — hardware PWM (phys pin 33). Right Trigger / W-S keys

PWM_FREQ   = 50
NEUTRAL_US = 1500
# ESCs: narrower range (100µs dead on each side of neutral is typical)
ESC_MIN_US = 1100
ESC_MAX_US = 1900
# Servos: full range for 0°–180° sweep
SERVO_MIN_US = 1000
SERVO_MAX_US = 2000

if GPIO_OK:
    for pin in (ESC_R_PIN, ESC_L_PIN, SERVO1_PIN, SERVO2_PIN):
        try:
            lgpio.gpio_claim_output(_chip, pin, 0)
        except Exception as e:
            print(f"[GPIO] Could not claim pin {pin}: {e}")

def set_pwm(pin: int, us: int, lo: int = 1000, hi: int = 2000) -> int:
    """Generic 50 Hz PWM by duty cycle — used for ESCs only."""
    us = max(lo, min(hi, int(us)))
    if GPIO_OK:
        try:
            duty = (us / 20_000.0) * 100.0
            lgpio.tx_pwm(_chip, pin, PWM_FREQ, duty)
        except Exception as e:
            print(f"[GPIO] tx_pwm error on pin {pin}: {e}")
    return us

def set_esc(pin: int, us: int) -> int:
    return set_pwm(pin, us, ESC_MIN_US, ESC_MAX_US)

def set_servo(pin: int, us: int) -> int:
    """Arduino-style servo.writeMicroseconds() using lgpio.tx_servo.
    This is a dedicated servo waveform generator — precise 50 Hz frame,
    microsecond-accurate pulse width, no duty-cycle drift. Much cleaner
    than tx_pwm for position-hold servos."""
    us = max(SERVO_MIN_US, min(SERVO_MAX_US, int(us)))
    if GPIO_OK:
        try:
            lgpio.tx_servo(_chip, pin, us)
        except Exception as e:
            print(f"[GPIO] tx_servo error on pin {pin}: {e}")
    return us

# Shared state (lock-guarded)
state = {
    "R": NEUTRAL_US, "L": NEUTRAL_US,
    "S1": NEUTRAL_US, "S2": NEUTRAL_US,
    "last_cmd": time.time(),
}
state_lock = threading.Lock()

def stop_all():
    set_esc(ESC_R_PIN, NEUTRAL_US)
    set_esc(ESC_L_PIN, NEUTRAL_US)
    set_servo(SERVO1_PIN, NEUTRAL_US)
    set_servo(SERVO2_PIN, NEUTRAL_US)
    with state_lock:
        state["R"] = state["L"] = state["S1"] = state["S2"] = NEUTRAL_US

def watchdog():
    """Cut motors if no command has arrived for 1 s. Safety net."""
    while True:
        time.sleep(0.25)
        with state_lock:
            idle = time.time() - state["last_cmd"]
            any_moving = (state["R"] != NEUTRAL_US or state["L"] != NEUTRAL_US)
        if idle > 1.0 and any_moving:
            set_esc(ESC_R_PIN, NEUTRAL_US)
            set_esc(ESC_L_PIN, NEUTRAL_US)
            with state_lock:
                state["R"] = state["L"] = NEUTRAL_US
            print(f"[WATCHDOG] Idle {idle:.1f}s — motors stopped.")

# ─────────────────────────────────────────────────────────────────────────────
# Camera  (lazy — won't block startup if unavailable)
# ─────────────────────────────────────────────────────────────────────────────
_cam_lock = threading.Lock()
_cam_state = {
    "thread": None,
    "jpeg": None,
    "stats": {
        "sargassum_pct":  0.0,
        "vegetation_pct": 0.0,
        "fps":            0.0,
        "online":         False,
    },
    "stop": False,
}

def camera_loop():
    """Capture + detect + encode. Runs forever in a daemon thread.

    Detection is pure HSV color thresholding — no ML model, no downloads:
        - Orange/brown pixels → sargassum
        - Green pixels → vegetation / coral
    Fast, lightweight, ~20fps on the Pi 5. Tune the HSV bands below if
    field conditions don't match (bright sun, cloudy, etc.).
    """
    try:
        import cv2
        import numpy as np
    except ImportError:
        print("[CAM] cv2/numpy not installed — video disabled.")
        return

    print("[CAM] Starting capture thread…")
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    SARG_LO, SARG_HI = np.array([8, 80, 60]),  np.array([28, 255, 230])
    VEG_LO,  VEG_HI  = np.array([35, 50, 40]), np.array([85, 255, 230])

    while not _cam_state["stop"]:
        cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
        if not cap.isOpened():
            cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("[CAM] /dev/video0 not available, retrying in 3 s…")
            _cam_state["stats"]["online"] = False
            time.sleep(3)
            continue

        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        cap.set(cv2.CAP_PROP_FPS,          20)
        cap.set(cv2.CAP_PROP_BUFFERSIZE,   1)
        print("[CAM] Opened device 0 @ 640x480")

        while not _cam_state["stop"]:
            t0 = time.time()
            ok, frame = cap.read()
            if not ok:
                print("[CAM] Lost frames, reopening…")
                break

            # Camera is mounted upside-down — rotate 180° before anything else.
            frame = cv2.rotate(frame, cv2.ROTATE_180)
            h, w = frame.shape[:2]
            total = h * w
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

            # ── Sargassum (orange-brown) ────────────────────────────────────
            sarg = cv2.inRange(hsv, SARG_LO, SARG_HI)
            sarg = cv2.morphologyEx(sarg, cv2.MORPH_OPEN,  kernel)
            sarg = cv2.morphologyEx(sarg, cv2.MORPH_CLOSE, kernel)
            sarg_pct = 100 * int(sarg.sum() / 255) / total
            for c in cv2.findContours(sarg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]:
                if cv2.contourArea(c) < 800:
                    continue
                x, y, bw, bh = cv2.boundingRect(c)
                cv2.rectangle(frame, (x, y), (x+bw, y+bh), (0, 140, 255), 2)
                cv2.putText(frame, "SARGASSUM", (x+3, y-4),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 140, 255), 1, cv2.LINE_AA)

            # ── Vegetation (green) ──────────────────────────────────────────
            veg = cv2.inRange(hsv, VEG_LO, VEG_HI)
            veg = cv2.morphologyEx(veg, cv2.MORPH_OPEN,  kernel)
            veg = cv2.morphologyEx(veg, cv2.MORPH_CLOSE, kernel)
            veg_pct = 100 * int(veg.sum() / 255) / total
            for c in cv2.findContours(veg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]:
                if cv2.contourArea(c) < 1500:
                    continue
                x, y, bw, bh = cv2.boundingRect(c)
                cv2.rectangle(frame, (x, y), (x+bw, y+bh), (0, 200, 0), 2)

            # ── HUD ─────────────────────────────────────────────────────────
            hud = f"SARG {sarg_pct:5.1f}%   VEG {veg_pct:5.1f}%"
            cv2.rectangle(frame, (0, 0), (260, 28), (0, 0, 0), -1)
            cv2.putText(frame, hud, (8, 19),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)

            ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
            if ok:
                fps = 1.0 / max(time.time() - t0, 1e-3)
                with _cam_lock:
                    _cam_state["jpeg"] = buf.tobytes()
                    _cam_state["stats"] = {
                        "sargassum_pct":  round(sarg_pct, 1),
                        "vegetation_pct": round(veg_pct, 1),
                        "fps":            round(fps, 1),
                        "online":         True,
                    }
        cap.release()

def ensure_camera():
    """Start the camera thread once, on first request."""
    with _cam_lock:
        if _cam_state["thread"] is None:
            t = threading.Thread(target=camera_loop, daemon=True)
            t.start()
            _cam_state["thread"] = t

# ─────────────────────────────────────────────────────────────────────────────
# IMU (MPU-9250) — lazy-initialised, polled by browser at ~5 Hz
# ─────────────────────────────────────────────────────────────────────────────
_imu_lock  = threading.Lock()
_imu_state = {
    "driver": None,        # MPU9250 instance once initialised
    "tried": False,        # true once we've attempted init (to avoid retry storm)
    "ok": False,
    "last": {              # last successful reading
        "ax": 0.0, "ay": 0.0, "az": 0.0,
        "gx": 0.0, "gy": 0.0, "gz": 0.0,
        "mx": 0.0, "my": 0.0, "mz": 0.0,
        "roll": 0.0, "pitch": 0.0, "yaw": 0.0,
        "mag_ok": False, "ok": False,
    },
}

def ensure_imu():
    """Initialise the IMU once, on first request. Safe to call repeatedly."""
    with _imu_lock:
        if _imu_state["tried"]:
            return _imu_state["ok"]
        _imu_state["tried"] = True
        try:
            from mpu9250 import MPU9250
            _imu_state["driver"] = MPU9250(bus=1)
            _imu_state["ok"] = True
            print("[IMU] MPU-9250 initialised on I²C bus 1")
        except Exception as e:
            _imu_state["ok"] = False
            print(f"[IMU] not available ({e}) — IMU panel will show OFFLINE")
        return _imu_state["ok"]

def imu_read() -> dict:
    """Return latest IMU reading, or zeros + ok=False if unavailable."""
    if not ensure_imu():
        d = dict(_imu_state["last"]); d["ok"] = False; return d
    try:
        with _imu_lock:
            data = _imu_state["driver"].read()
        data["ok"] = True
        _imu_state["last"] = data
        return data
    except Exception as e:
        print(f"[IMU] read error: {e}")
        d = dict(_imu_state["last"]); d["ok"] = False; return d

def mjpeg_generator():
    """Stream the latest JPEG to the client at ~15 fps."""
    import numpy as np
    import cv2
    placeholder = None
    interval = 1.0 / 15
    last = 0.0
    while True:
        now = time.time()
        if now - last < interval:
            time.sleep(max(0, interval - (now - last)))
        last = time.time()
        with _cam_lock:
            jpeg = _cam_state["jpeg"]
        if jpeg is None:
            if placeholder is None:
                img = np.zeros((480, 640, 3), dtype=np.uint8)
                cv2.putText(img, "NO CAMERA SIGNAL", (160, 240),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.9, (90, 90, 90), 2, cv2.LINE_AA)
                _, b = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 50])
                placeholder = b.tobytes()
            jpeg = placeholder
        yield (b"--frame\r\nContent-Type: image/jpeg\r\n"
               b"Content-Length: " + str(len(jpeg)).encode() + b"\r\n\r\n"
               + jpeg + b"\r\n")

# ─────────────────────────────────────────────────────────────────────────────
# Database
# ─────────────────────────────────────────────────────────────────────────────
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kaax.db")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def _hash(pw: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), b"kaax_salt_v1", 120_000).hex()

def init_db():
    first_run = not os.path.exists(DB_PATH)
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            pw_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            kind TEXT NOT NULL,
            username TEXT,
            message TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username   TEXT NOT NULL,
            started_at TEXT NOT NULL,
            ended_at   TEXT,
            estops     INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS samples (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            ts         TEXT    NOT NULL,
            sarg_pct   REAL    DEFAULT 0,
            veg_pct    REAL    DEFAULT 0,
            thrust_r   INTEGER DEFAULT 1500,
            thrust_l   INTEGER DEFAULT 1500,
            FOREIGN KEY (session_id) REFERENCES sessions(id)
        );
        CREATE INDEX IF NOT EXISTS idx_samples_session ON samples(session_id);
        CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(username);
        """)
        if first_run:
            for u in ("admin", "diego", "yael", "carvajal"):
                conn.execute(
                    "INSERT INTO users(username, pw_hash, created_at) VALUES(?,?,?)",
                    (u, _hash("kaax2026"), datetime.utcnow().isoformat()),
                )
            print("[DB] Seeded 4 default users (pw: kaax2026)")

def verify(u: str, p: str) -> bool:
    with db() as conn:
        row = conn.execute("SELECT pw_hash FROM users WHERE username=?", (u,)).fetchone()
    return bool(row) and row["pw_hash"] == _hash(p)

def log_event(kind: str, message: str, username: str = None):
    with db() as conn:
        conn.execute(
            "INSERT INTO logs(ts, kind, username, message) VALUES(?,?,?,?)",
            (datetime.utcnow().isoformat(), kind, username, message),
        )

# ─────────────────────────────────────────────────────────────────────────────
# Session tracking + sample recording (analytics foundation)
# ─────────────────────────────────────────────────────────────────────────────
# A "session" starts when a user opens the tele-op page and ends when they
# log out, close the page, or trigger an e-stop that is never followed up.
# Samples are recorded every ~2s while a session is active.
SAMPLE_INTERVAL_S = 2.0
_sample_thread_started = False

def session_start(username: str) -> int:
    with db() as conn:
        cur = conn.execute(
            "INSERT INTO sessions(username, started_at) VALUES(?,?)",
            (username, datetime.utcnow().isoformat()),
        )
        return cur.lastrowid

def session_end(session_id: int):
    if not session_id:
        return
    with db() as conn:
        conn.execute(
            "UPDATE sessions SET ended_at=? WHERE id=? AND ended_at IS NULL",
            (datetime.utcnow().isoformat(), session_id),
        )

def session_bump_estops(session_id: int):
    if not session_id:
        return
    with db() as conn:
        conn.execute(
            "UPDATE sessions SET estops = estops + 1 WHERE id=?",
            (session_id,),
        )

def _sample_recorder():
    """Every SAMPLE_INTERVAL_S seconds, log a row of current telemetry
    into the samples table for whichever session is currently active."""
    while True:
        time.sleep(SAMPLE_INTERVAL_S)
        sid = _active_session.get("id")
        if not sid:
            continue
        with state_lock:
            r, l = state["R"], state["L"]
        with _cam_lock:
            st = _cam_state["stats"]
            sarg = st.get("sargassum_pct", 0.0)
            veg  = st.get("vegetation_pct", 0.0)
        try:
            with db() as conn:
                conn.execute(
                    "INSERT INTO samples(session_id, ts, sarg_pct, veg_pct, thrust_r, thrust_l) "
                    "VALUES(?,?,?,?,?,?)",
                    (sid, datetime.utcnow().isoformat(), sarg, veg, r, l),
                )
        except Exception as e:
            print(f"[SAMPLE] write failed: {e}")

# One active session per server process (single-user ROV)
_active_session = {"id": None, "username": None}

def ensure_sampler():
    global _sample_thread_started
    if not _sample_thread_started:
        threading.Thread(target=_sample_recorder, daemon=True).start()
        _sample_thread_started = True

# ─────────────────────────────────────────────────────────────────────────────
# Flask app
# ─────────────────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = secrets.token_hex(32)

def login_required(f):
    @wraps(f)
    def w(*a, **kw):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*a, **kw)
    return w

@app.route("/")
def index():
    return redirect(url_for("menu" if "user" in session else "login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    err = None
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        if verify(u, p):
            session["user"] = u
            log_event("login", f"{u} logged in", u)
            return redirect(url_for("menu"))
        err = "Invalid credentials"
    return render_template("login.html", error=err)

@app.route("/logout")
def logout():
    if "user" in session:
        log_event("logout", f"{session['user']} logged out", session["user"])
        # Close the active session row
        if _active_session.get("id"):
            session_end(_active_session["id"])
            _active_session["id"] = None
            _active_session["username"] = None
    session.clear()
    return redirect(url_for("login"))

@app.route("/menu")
@login_required
def menu():
    return render_template("menu.html", user=session["user"])

@app.route("/teleop")
@login_required
def teleop():
    ensure_camera()   # lazy-start on first visit
    ensure_sampler()  # start the 2s sample recorder
    # Start a new session if none is active (or if a different user took over)
    user = session["user"]
    if _active_session.get("id") is None or _active_session.get("username") != user:
        if _active_session.get("id") is not None:
            session_end(_active_session["id"])  # close orphaned session
        _active_session["id"] = session_start(user)
        _active_session["username"] = user
        log_event("session_start", f"Session #{_active_session['id']} started", user)
    return render_template("teleop.html", user=user)

@app.route("/logs")
@login_required
def logs_page():
    with db() as conn:
        rows = conn.execute(
            "SELECT ts, kind, username, message FROM logs ORDER BY id DESC LIMIT 200"
        ).fetchall()
    return render_template("logs.html", user=session["user"], logs=rows)

# ── Control API (plain HTTP, ~15 Hz from the browser) ───────────────────────
@app.route("/api/cmd", methods=["POST"])
@login_required
def api_cmd():
    """Payload: {R, L, S1, S2}  — any subset is fine."""
    data = request.get_json(silent=True) or {}
    with state_lock:
        if "R" in data:
            state["R"] = set_esc(ESC_R_PIN, data["R"])
        if "L" in data:
            state["L"] = set_esc(ESC_L_PIN, data["L"])
        if "S1" in data:
            state["S1"] = set_servo(SERVO1_PIN, data["S1"])
        if "S2" in data:
            state["S2"] = set_servo(SERVO2_PIN, data["S2"])
        state["last_cmd"] = time.time()
        snapshot = dict(state)
    return jsonify(snapshot)

@app.route("/api/stop", methods=["POST"])
@login_required
def api_stop():
    stop_all()
    log_event("stop", "Emergency stop", session.get("user"))
    if _active_session.get("id"):
        session_bump_estops(_active_session["id"])
    return jsonify(ok=True)

@app.route("/api/status")
@login_required
def api_status():
    with state_lock:
        snap = dict(state)
    return jsonify(snap)

@app.route("/api/vision")
@login_required
def api_vision():
    ensure_camera()
    with _cam_lock:
        return jsonify(_cam_state["stats"])

@app.route("/api/imu")
@login_required
def api_imu():
    """Latest IMU reading. Always returns a 200 (with ok=False if offline)."""
    return jsonify(imu_read())

@app.route("/video")
@login_required
def video_stream():
    ensure_camera()
    return Response(
        mjpeg_generator(),
        mimetype="multipart/x-mixed-replace; boundary=--frame",
    )

# ─────────────────────────────────────────────────────────────────────────────
# Analytics — session reports + historical aggregates
# ─────────────────────────────────────────────────────────────────────────────
# PWM is 1100–1900 µs for ESCs. A rough "distance travelled" estimate treats
# any deviation from neutral as proportional to speed, then integrates over
# the sample cadence. Numbers below are approximate — re-calibrate from field
# trials by measuring real travel distance vs. integrated PWM-seconds.
NEUTRAL_PWM = 1500
MAX_PWM_OFFSET = 400          # 1900 - 1500 = full speed
ASSUMED_TOP_SPEED_M_S = 0.8   # rough top speed of the ROV at full throttle

def _session_stats(session_id: int) -> dict:
    """Compute all derived metrics for one session. Used by both the GUI
    analytics view and the PDF report generator."""
    with db() as conn:
        sess = conn.execute(
            "SELECT * FROM sessions WHERE id=?", (session_id,)
        ).fetchone()
        if not sess:
            return {}
        samples = conn.execute(
            "SELECT ts, sarg_pct, veg_pct, thrust_r, thrust_l "
            "FROM samples WHERE session_id=? ORDER BY id", (session_id,)
        ).fetchall()

    started = datetime.fromisoformat(sess["started_at"])
    ended   = datetime.fromisoformat(sess["ended_at"]) if sess["ended_at"] else datetime.utcnow()
    duration_s = (ended - started).total_seconds()

    # Aggregate over all samples
    peak_sarg = 0.0
    sum_sarg  = 0.0
    thrust_time_s  = 0.0
    distance_m     = 0.0
    sarg_series = []  # (seconds-from-start, sarg_pct) for plotting

    for row in samples:
        sp = float(row["sarg_pct"] or 0)
        sum_sarg += sp
        peak_sarg = max(peak_sarg, sp)
        r, l = int(row["thrust_r"] or NEUTRAL_PWM), int(row["thrust_l"] or NEUTRAL_PWM)
        offs = (abs(r - NEUTRAL_PWM) + abs(l - NEUTRAL_PWM)) / 2.0  # avg side
        if offs > 10:
            thrust_time_s += SAMPLE_INTERVAL_S
            speed = (offs / MAX_PWM_OFFSET) * ASSUMED_TOP_SPEED_M_S
            distance_m += speed * SAMPLE_INTERVAL_S
        t_rel = (datetime.fromisoformat(row["ts"]) - started).total_seconds()
        sarg_series.append((t_rel, sp))

    avg_sarg = sum_sarg / len(samples) if samples else 0.0

    return {
        "id":          sess["id"],
        "username":    sess["username"],
        "started_at":  sess["started_at"],
        "ended_at":    sess["ended_at"],
        "active":      sess["ended_at"] is None,
        "estops":      sess["estops"] or 0,
        "duration_s":  duration_s,
        "samples":     len(samples),
        "peak_sarg":   round(peak_sarg, 1),
        "avg_sarg":    round(avg_sarg, 1),
        "thrust_time_s": round(thrust_time_s, 1),
        "distance_m":  round(distance_m, 1),
        "sarg_series": sarg_series,
    }

def _fmt_duration(seconds: float) -> str:
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}h {m}m {s}s"
    if m:
        return f"{m}m {s}s"
    return f"{s}s"

@app.route("/analytics")
@login_required
def analytics_page():
    """Historical aggregate view — lifetime stats + recent session list."""
    with db() as conn:
        # Lifetime totals (OLAP-style aggregations over all sessions + samples)
        totals = conn.execute("""
            SELECT
              COUNT(DISTINCT s.id)              AS total_sessions,
              COALESCE(SUM(s.estops), 0)        AS total_estops,
              COUNT(DISTINCT s.username)        AS unique_users
            FROM sessions s
        """).fetchone()
        peak = conn.execute(
            "SELECT COALESCE(MAX(sarg_pct), 0) AS peak_sarg FROM samples"
        ).fetchone()
        # Per-user rollup
        per_user = conn.execute("""
            SELECT
              username,
              COUNT(id) AS sess_count,
              COALESCE(SUM(estops), 0) AS estop_count
            FROM sessions
            GROUP BY username
            ORDER BY sess_count DESC
        """).fetchall()
        # Recent session list (20 newest)
        recent = conn.execute("""
            SELECT id, username, started_at, ended_at, estops
            FROM sessions
            ORDER BY id DESC
            LIMIT 20
        """).fetchall()

    # Compute derived fields
    recent_rows = []
    for r in recent:
        started = datetime.fromisoformat(r["started_at"])
        ended   = datetime.fromisoformat(r["ended_at"]) if r["ended_at"] else datetime.utcnow()
        recent_rows.append({
            "id":         r["id"],
            "username":   r["username"],
            "started_at": started.strftime("%Y-%m-%d %H:%M"),
            "duration":   _fmt_duration((ended - started).total_seconds()),
            "estops":     r["estops"] or 0,
            "active":     r["ended_at"] is None,
        })

    return render_template(
        "analytics.html",
        user=session["user"],
        totals={
            "sessions":     totals["total_sessions"],
            "estops":       totals["total_estops"],
            "users":        totals["unique_users"],
            "peak_sarg":    round(peak["peak_sarg"] or 0, 1),
        },
        per_user=per_user,
        recent=recent_rows,
    )

@app.route("/api/session/<int:session_id>/report.pdf")
@login_required
def session_pdf(session_id):
    """Generate a PDF summary for one session, streamed back to the browser."""
    stats = _session_stats(session_id)
    if not stats:
        return "Session not found", 404
    pdf_bytes = _build_session_pdf(stats)
    return Response(
        pdf_bytes,
        mimetype="application/pdf",
        headers={
            "Content-Disposition":
                f'attachment; filename="kaax_session_{session_id}.pdf"',
        },
    )

def _build_session_pdf(st: dict) -> bytes:
    """Generate a single-page PDF using reportlab. Includes summary metrics
    table and a sargassum-coverage-over-time line chart."""
    from io import BytesIO
    from reportlab.lib.pagesizes import LETTER
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image,
    )
    from reportlab.graphics.shapes import Drawing, String, Line
    from reportlab.graphics.charts.linecharts import HorizontalLineChart
    from reportlab.graphics.charts.textlabels import Label

    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=LETTER,
        leftMargin=0.75*inch, rightMargin=0.75*inch,
        topMargin=0.75*inch, bottomMargin=0.75*inch,
        title=f"Kaax Session {st['id']}",
    )

    styles = getSampleStyleSheet()
    TEAL = colors.HexColor("#0F6E56")
    INK  = colors.HexColor("#0A2535")
    MUTED = colors.HexColor("#6B8A9C")
    title_st = ParagraphStyle("t", parent=styles["Title"],
                              textColor=TEAL, fontName="Helvetica-Bold",
                              fontSize=22, spaceAfter=4)
    sub_st = ParagraphStyle("s", parent=styles["Normal"],
                            textColor=MUTED, fontName="Helvetica",
                            fontSize=10, spaceAfter=12)
    body_st = ParagraphStyle("b", parent=styles["Normal"],
                             textColor=INK, fontName="Helvetica",
                             fontSize=11, leading=16, spaceAfter=6)
    h2_st = ParagraphStyle("h2", parent=styles["Heading2"],
                           textColor=INK, fontName="Helvetica-Bold",
                           fontSize=13, spaceBefore=12, spaceAfter=6)

    story = []
    story.append(Paragraph("KAAX · Session Report", title_st))
    story.append(Paragraph(
        f"Session #{st['id']} · DAY1 Robotics · "
        f"Generated {datetime.utcnow().strftime('%Y-%m-%d %H:%M')} UTC",
        sub_st))

    # Key metrics table
    def row(k, v): return [Paragraph(f"<b>{k}</b>", body_st),
                           Paragraph(str(v), body_st)]
    metrics = [
        row("Operator",             st["username"]),
        row("Started",              st["started_at"].replace("T", " ")[:19] + " UTC"),
        row("Ended",                (st["ended_at"].replace("T", " ")[:19] + " UTC")
                                     if st["ended_at"] else "— (active)"),
        row("Duration",             _fmt_duration(st["duration_s"])),
        row("Samples recorded",     st["samples"]),
        row("Thrust time",          _fmt_duration(st["thrust_time_s"])),
        row("Distance (estimate)",  f"{st['distance_m']:.1f} m"),
        row("Peak sargassum",       f"{st['peak_sarg']:.1f} %"),
        row("Average sargassum",    f"{st['avg_sarg']:.1f} %"),
        row("Emergency stops",      st["estops"]),
    ]
    tbl = Table(metrics, colWidths=[2.0*inch, 4.5*inch])
    tbl.setStyle(TableStyle([
        ("VALIGN",     (0, 0), (-1, -1), "TOP"),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#F4F8FA")),
        ("LINEBELOW",  (0, 0), (-1, -1), 0.3, colors.HexColor("#D5E0E6")),
        ("LEFTPADDING",  (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING",    (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(tbl)

    # Sargassum over time chart
    if st["sarg_series"]:
        story.append(Paragraph("Sargassum coverage over time", h2_st))
        d = Drawing(460, 200)
        chart = HorizontalLineChart()
        chart.x, chart.y = 50, 30
        chart.width, chart.height = 380, 150
        chart.lines[0].strokeColor = TEAL
        chart.lines[0].strokeWidth = 1.5
        chart.data = [[pt[1] for pt in st["sarg_series"]]]
        chart.categoryAxis.labels.boxAnchor = "n"
        chart.categoryAxis.labels.fontSize = 7
        chart.categoryAxis.labels.fontName = "Helvetica"
        chart.valueAxis.valueMin = 0
        chart.valueAxis.valueMax = max(5, st["peak_sarg"] * 1.2)
        chart.valueAxis.labels.fontSize = 8
        chart.valueAxis.labels.fontName = "Helvetica"
        # Show a sparse set of x-axis labels
        n = len(st["sarg_series"])
        step = max(1, n // 6)
        chart.categoryAxis.categoryNames = [
            f"{int(st['sarg_series'][i][0])}s" if i % step == 0 else ""
            for i in range(n)
        ]
        d.add(chart)
        y_label = String(15, 100, "Sarg %", fontName="Helvetica",
                         fontSize=9, fillColor=MUTED)
        y_label.textAnchor = "middle"
        d.add(y_label)
        story.append(d)
    else:
        story.append(Paragraph("Sargassum coverage over time", h2_st))
        story.append(Paragraph(
            "<i>No samples recorded — the session was too short or the camera "
            "was offline.</i>", body_st))

    story.append(Spacer(1, 12))
    story.append(Paragraph(
        f"<font color='#6B8A9C'>DAY1 Robotics · Kaax ROV · "
        f"Riviera Maya, México · 2026</font>", body_st))

    doc.build(story)
    return buf.getvalue()

# ── Entry point ─────────────────────────────────────────────────────────────
def main():
    init_db()
    threading.Thread(target=watchdog, daemon=True).start()
    port = 80 if os.geteuid() == 0 else 8080
    print(f"[SERVER] Listening on http://0.0.0.0:{port}")
    print(f"[SERVER] Login: admin / kaax2026")
    # threaded=True lets multiple clients + the MJPEG stream coexist.
    app.run(host="0.0.0.0", port=port, threaded=True, debug=False, use_reloader=False)

if __name__ == "__main__":
    main()
