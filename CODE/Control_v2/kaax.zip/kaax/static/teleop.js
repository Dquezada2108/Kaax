/* Kaax Tele-Op · plain HTTP polling (no websockets)
   ------------------------------------------------
   Controls:
     Keyboard:
       Arrows   → thrusters (binary on/off with per-motor trim sliders)
       A / D    → Servo 1 ±10°
       W / S    → Servo 2 ±10°
       Space    → emergency stop
     Xbox controller:
       Left stick → thrusters (binary, any deflection = full signal)
       D-pad ←/→  → Servo 1 ±10° (edge-triggered, one tap per press)
       D-pad ↑/↓  → Servo 2 ±10°
       B button   → emergency stop

   Each motor has an independent forward/reverse trim slider (0-100%).
   Servos hold their last commanded angle; the server keeps sending pulses.
*/
(() => {
  const NEU = 1500;
  const PWM_RANGE = 400;
  const SERVO_STEP_DEG = 10;
  const SERVO_MIN_DEG = 0;
  const SERVO_MAX_DEG = 180;

  const $ = id => document.getElementById(id);

  // UI refs
  const rv = $('rv'), lv = $('lv'), rb = $('rb'), lb = $('lb');
  const sv = $('sv'), iv = $('iv');
  const vSarg = $('v-sarg'), vVeg = $('v-veg');
  const vSargBar = $('v-sarg-bar'), vVegBar = $('v-veg-bar');
  const vFps = $('v-fps'), vStatus = $('v-status');
  const pill = $('conn-pill'), pillLbl = pill.querySelector('.conn-lbl');
  const camBadge = $('cam-badge');

  // Per-motor trim sliders (0-100 %)
  const trim = { rFwd: 60, rRev: 60, lFwd: 60, lRev: 60 };
  function bindTrim(id, key) {
    const el = $(id), out = $(id + '-v');
    el.addEventListener('input', () => {
      trim[key] = +el.value;
      out.textContent = el.value;
      calcFromKeys();
    });
  }
  bindTrim('trim-r-fwd', 'rFwd');
  bindTrim('trim-r-rev', 'rRev');
  bindTrim('trim-l-fwd', 'lFwd');
  bindTrim('trim-l-rev', 'lRev');

  const pctToFwd = pct => Math.round(NEU + (pct / 100) * PWM_RANGE);
  const pctToRev = pct => Math.round(NEU - (pct / 100) * PWM_RANGE);

  // Servos — state kept in degrees
  const servo = { s1: 90, s2: 90 };
  const degToUs = deg => Math.round(1000 + (deg / 180) * 1000);

  function setServo(which, deg) {
    deg = Math.max(SERVO_MIN_DEG, Math.min(SERVO_MAX_DEG, deg));
    servo[which] = deg;
    $(which === 's1' ? 's1-angle' : 's2-angle').textContent = deg + '°';
    queueSend();
  }
  function stepServo(which, delta) { setServo(which, servo[which] + delta); }

  $('s1-dec').addEventListener('click', () => stepServo('s1', -SERVO_STEP_DEG));
  $('s1-inc').addEventListener('click', () => stepServo('s1', +SERVO_STEP_DEG));
  $('s2-dec').addEventListener('click', () => stepServo('s2', -SERVO_STEP_DEG));
  $('s2-inc').addEventListener('click', () => stepServo('s2', +SERVO_STEP_DEG));

  // Throttled sender (~15 Hz)
  const motorState = { R: NEU, L: NEU };
  let lastSent = { R: NEU, L: NEU, S1: degToUs(90), S2: degToUs(90) };
  let sendTimer = null;
  let online = false;

  function queueSend() {
    if (sendTimer) return;
    sendTimer = setTimeout(async () => {
      sendTimer = null;
      const payload = {};
      if (motorState.R !== lastSent.R) payload.R = motorState.R;
      if (motorState.L !== lastSent.L) payload.L = motorState.L;
      const s1us = degToUs(servo.s1);
      const s2us = degToUs(servo.s2);
      if (s1us !== lastSent.S1) payload.S1 = s1us;
      if (s2us !== lastSent.S2) payload.S2 = s2us;
      if (Object.keys(payload).length === 0) return;
      try {
        const r = await fetch('/api/cmd', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        if (r.ok) { Object.assign(lastSent, payload); setOnline(true); }
        else setOnline(false);
      } catch (e) { setOnline(false); }
    }, 66);
  }

  function setOnline(up) {
    if (up === online) return;
    online = up;
    pill.className = 'conn-pill ' + (up ? 'online' : 'offline');
    pillLbl.textContent = up ? 'CONNECTED' : 'OFFLINE';
  }

  function updateThrusterUI() {
    const R = motorState.R, L = motorState.L;
    rv.textContent = R; lv.textContent = L;
    rb.style.width = ((R - 1100) / 800 * 100) + '%';
    lb.style.width = ((L - 1100) / 800 * 100) + '%';
    sv.classList.remove('state-idle','state-fwd','state-bwd','state-turn');
    let s = 'IDLE', c = 'state-idle';
    if (R === NEU && L === NEU) { s = 'IDLE'; c = 'state-idle'; }
    else if (R > NEU && L > NEU) { s = 'FORWARD'; c = 'state-fwd'; }
    else if (R < NEU && L < NEU) { s = 'REVERSE'; c = 'state-bwd'; }
    else { s = 'TURNING'; c = 'state-turn'; }
    sv.textContent = s;
    sv.classList.add(c);
  }

  const keys = { ArrowUp:0, ArrowDown:0, ArrowLeft:0, ArrowRight:0 };
  const BM   = { ArrowUp:'bu', ArrowDown:'bd', ArrowLeft:'bl', ArrowRight:'br' };
  const stickFlags = { up:0, down:0, left:0, right:0 };

  function calcFromKeys() {
    // The pilot reported the controls felt rotated 90° counter-clockwise
    // (↑ pivoted left, ← went forward).  We rotate the four inputs 90°
    // clockwise here so the steering matrix below stays readable.
    //   physical key  →  logical role
    //   ↑                 ←
    //   ←                 ↓
    //   ↓                 →
    //   →                 ↑
    const u = keys.ArrowRight || stickFlags.right;
    const d = keys.ArrowLeft  || stickFlags.left;
    const l = keys.ArrowUp    || stickFlags.up;
    const r = keys.ArrowDown  || stickFlags.down;

    let R = NEU, L = NEU;
    if (u && l)      { R = pctToFwd(trim.rFwd); L = NEU; }
    else if (u && r) { R = NEU;                 L = pctToFwd(trim.lFwd); }
    else if (d && l) { R = pctToRev(trim.rRev); L = NEU; }
    else if (d && r) { R = NEU;                 L = pctToRev(trim.lRev); }
    else if (u)      { R = pctToFwd(trim.rFwd); L = pctToFwd(trim.lFwd); }
    else if (d)      { R = pctToRev(trim.rRev); L = pctToRev(trim.lRev); }
    else if (l)      { R = pctToFwd(trim.rFwd); L = pctToRev(trim.lRev); }
    else if (r)      { R = pctToRev(trim.rRev); L = pctToFwd(trim.lFwd); }

    motorState.R = R; motorState.L = L;
    updateThrusterUI();
    queueSend();
  }

  // Keyboard
  document.addEventListener('keydown', e => {
    if (e.key === ' ') { e.preventDefault(); doEstop(); return; }
    if (e.key in keys) {
      e.preventDefault();
      if (keys[e.key]) return;
      keys[e.key] = 1;
      $(BM[e.key]).classList.add('on');
      iv.textContent = 'KEYBOARD';
      calcFromKeys();
      return;
    }
    const k = e.key.toLowerCase();
    if (e.repeat) return;   // ignore key-repeat on WASD
    if (k === 'a') { e.preventDefault(); stepServo('s1', -SERVO_STEP_DEG); iv.textContent='KEYBOARD'; }
    else if (k === 'd') { e.preventDefault(); stepServo('s1', +SERVO_STEP_DEG); iv.textContent='KEYBOARD'; }
    else if (k === 'w') { e.preventDefault(); stepServo('s2', +SERVO_STEP_DEG); iv.textContent='KEYBOARD'; }
    else if (k === 's') { e.preventDefault(); stepServo('s2', -SERVO_STEP_DEG); iv.textContent='KEYBOARD'; }
  });
  document.addEventListener('keyup', e => {
    if (!(e.key in keys)) return;
    keys[e.key] = 0;
    $(BM[e.key]).classList.remove('on');
    calcFromKeys();
  });

  // On-screen D-pad (thrusters only)
  document.querySelectorAll('.db').forEach(btn => {
    const k = btn.dataset.k;
    const on  = e => { e.preventDefault(); keys[k] = 1; btn.classList.add('on'); iv.textContent='TOUCH'; calcFromKeys(); };
    const off = e => { e.preventDefault(); keys[k] = 0; btn.classList.remove('on'); calcFromKeys(); };
    btn.addEventListener('mousedown', on);
    btn.addEventListener('mouseup',   off);
    btn.addEventListener('mouseleave',off);
    btn.addEventListener('touchstart',on,  { passive: false });
    btn.addEventListener('touchend',  off, { passive: false });
  });

  // E-stop
  async function doEstop() {
    Object.keys(keys).forEach(k => keys[k] = 0);
    Object.keys(stickFlags).forEach(k => stickFlags[k] = 0);
    document.querySelectorAll('.db').forEach(b => b.classList.remove('on'));
    motorState.R = motorState.L = NEU;
    servo.s1 = 90; servo.s2 = 90;
    $('s1-angle').textContent = '90°';
    $('s2-angle').textContent = '90°';
    updateThrusterUI();
    try { await fetch('/api/stop', { method: 'POST' }); } catch(e) {}
  }
  $('estop').addEventListener('click', doEstop);

  // Xbox controller
  const STICK_DEAD = 0.35;
  let lastGpAt = 0;
  const prevDpad = { up:0, down:0, left:0, right:0 };

  window.addEventListener('gamepadconnected', e => console.log('[GP]', e.gamepad.id));

  function gamepadLoop() {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    const gp = pads && Array.from(pads).find(p => p);
    if (gp) {
      // Left stick → binary direction flags
      const x = gp.axes[0] || 0;
      const y = -(gp.axes[1] || 0);
      const newStick = {
        up:    y >  STICK_DEAD ? 1 : 0,
        down:  y < -STICK_DEAD ? 1 : 0,
        left:  x < -STICK_DEAD ? 1 : 0,
        right: x >  STICK_DEAD ? 1 : 0,
      };
      const stickChanged = Object.keys(newStick).some(k => newStick[k] !== stickFlags[k]);
      if (stickChanged) {
        Object.assign(stickFlags, newStick);
        if (Object.values(newStick).some(v => v)) iv.textContent = 'GAMEPAD';
        calcFromKeys();
      }

      // D-pad edge-triggered servo steps. Xbox buttons: 12↑ 13↓ 14← 15→
      const dpad = {
        up:    gp.buttons[12] && gp.buttons[12].pressed ? 1 : 0,
        down:  gp.buttons[13] && gp.buttons[13].pressed ? 1 : 0,
        left:  gp.buttons[14] && gp.buttons[14].pressed ? 1 : 0,
        right: gp.buttons[15] && gp.buttons[15].pressed ? 1 : 0,
      };
      if (dpad.left  && !prevDpad.left)  { stepServo('s1', -SERVO_STEP_DEG); iv.textContent='GAMEPAD'; }
      if (dpad.right && !prevDpad.right) { stepServo('s1', +SERVO_STEP_DEG); iv.textContent='GAMEPAD'; }
      if (dpad.up    && !prevDpad.up)    { stepServo('s2', +SERVO_STEP_DEG); iv.textContent='GAMEPAD'; }
      if (dpad.down  && !prevDpad.down)  { stepServo('s2', -SERVO_STEP_DEG); iv.textContent='GAMEPAD'; }
      Object.assign(prevDpad, dpad);

      // B button (index 1) → e-stop
      if (gp.buttons[1] && gp.buttons[1].pressed) { doEstop(); }

      if (stickChanged || Object.values(dpad).some(v => v)) lastGpAt = Date.now();
    } else if (Date.now() - lastGpAt > 1500) {
      if (iv.textContent === 'GAMEPAD') iv.textContent = 'KEYBOARD';
    }
    requestAnimationFrame(gamepadLoop);
  }
  requestAnimationFrame(gamepadLoop);

  // Vision poll
  async function pollVision() {
    try {
      const r = await fetch('/api/vision');
      if (!r.ok) return;
      const d = await r.json();
      const sa = d.sargassum_pct || 0;
      const vg = d.vegetation_pct || 0;
      vSarg.textContent = sa.toFixed(1) + '%';
      vVeg.textContent  = vg.toFixed(1) + '%';
      vSargBar.style.width = Math.min(100, sa * 3.3) + '%';
      vVegBar.style.width  = Math.min(100, vg * 2.0) + '%';
      vFps.textContent    = d.fps ? d.fps.toFixed(1) : '—';
      vStatus.textContent = d.online ? 'LIVE' : 'OFFLINE';
      camBadge.classList.toggle('live', d.online);
      camBadge.querySelector('span:last-child').textContent = d.online ? 'LIVE' : 'OFFLINE';
    } catch(e) {}
  }
  setInterval(pollVision, 500);
  pollVision();

  // Heartbeat
  async function heartbeat() {
    try { setOnline((await fetch('/api/status')).ok); }
    catch(e) { setOnline(false); }
  }
  setInterval(heartbeat, 2000);
  heartbeat();

  // Periodic thruster re-send — a dedicated watchdog feeder. Fires every
  // 400 ms and unconditionally re-sends the current motor state directly
  // (bypassing queueSend's change-detection) whenever motors are non-neutral.
  // This prevents motor stutter caused by the in-flight response clobbering
  // lastSent during a change-detection reset.
  setInterval(async () => {
    if (motorState.R === NEU && motorState.L === NEU) return;
    try {
      const r = await fetch('/api/cmd', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ R: motorState.R, L: motorState.L }),
      });
      if (r.ok) setOnline(true); else setOnline(false);
    } catch (e) { setOnline(false); }
  }, 400);

  // ── IMU poller ────────────────────────────────────────────────────────────
  // Poll /api/imu at 5 Hz. Updates the artificial horizon, compass dial, and
  // raw 9-axis numbers. Gracefully degrades to OFFLINE if the IMU isn't
  // connected (server still returns 200 with ok=false).
  const horizonRot   = document.getElementById('horizon-rot');
  const horizonPitch = document.getElementById('horizon-pitch');
  const compassRot   = document.getElementById('compass-rot');
  const imuStatus    = document.getElementById('imu-status');
  const imuStatusLbl = document.getElementById('imu-status-lbl');
  const fmt = n => (Math.round(n * 100) / 100).toFixed(2);

  async function pollImu() {
    try {
      const r = await fetch('/api/imu');
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const d = await r.json();
      // Artificial horizon: roll rotates the whole inner group, pitch
      // translates the horizon line up/down (~1.4 px per degree).
      if (horizonRot && horizonPitch) {
        horizonRot.setAttribute(  'transform', `rotate(${-d.roll})`);
        horizonPitch.setAttribute('transform', `translate(0, ${d.pitch * 1.4})`);
      }
      // Compass: rotate the cardinal labels opposite to yaw so red needle
      // (which is fixed pointing up) shows current heading.
      if (compassRot) compassRot.setAttribute('transform', `rotate(${-d.yaw})`);

      document.getElementById('imu-roll').textContent  = `${d.roll.toFixed(0)}°`;
      document.getElementById('imu-pitch').textContent = `${d.pitch.toFixed(0)}°`;
      document.getElementById('imu-yaw').textContent   = `${d.yaw.toFixed(0)}°`;

      ['ax','ay','az','gx','gy','gz','mx','my','mz'].forEach(k => {
        const el = document.getElementById('imu-' + k);
        if (el) el.textContent = fmt(d[k]);
      });

      if (imuStatus) {
        imuStatus.classList.toggle('live', d.ok);
        imuStatusLbl.textContent = d.ok
          ? (d.mag_ok ? 'LIVE · 9-AXIS' : 'LIVE · NO MAG')
          : 'OFFLINE';
      }
    } catch (e) {
      if (imuStatus) {
        imuStatus.classList.remove('live');
        imuStatusLbl.textContent = 'OFFLINE';
      }
    }
  }
  setInterval(pollImu, 200);
  pollImu();

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) doEstop();
  });
})();
